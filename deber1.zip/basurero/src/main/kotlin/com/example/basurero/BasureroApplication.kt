package com.example.basurero

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class BasureroApplication

fun main(args: Array<String>) {
	runApplication<BasureroApplication>(*args)
}
