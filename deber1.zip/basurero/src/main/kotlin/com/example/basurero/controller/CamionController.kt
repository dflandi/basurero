

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*


@RestController
@RequestMapping("/ Camion´s")
@CrossOrigin(methods = [RequestMethod.GET, RequestMethod.POST, RequestMethod.PATCH])
class CamionController {

    @Autowired
    lateinit var camionService: CamionService

    @GetMapping
    fun list ():List <Camion>{
        return camionService.list()
    }

    @PostMapping
    fun save(@RequestBody camion:Camion):Camion{
        return camionService.save(camion)
    }
}

