import javax.persistence.*

@Entity
@Table(name="nombre_tabla")
class Camion{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(updatable=false)
    var Horas: Long? = null
    var Dias: String? = null

}