import javax.persistence.*

@Entity
@Table(name="nombre_tabla")
class Rutas{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(updatable=false)
    var TiempoRutas: Long? = null
    var NombreRutas: String? = null

}