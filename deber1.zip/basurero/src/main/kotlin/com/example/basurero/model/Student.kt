import javax.persistence.*

@Entity
@Table(name="nombre_tabla")
class Student{
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(updatable=false)
    var id: Long? = null
    var atribute: String? = null

}