package com.example.basurero.repository
import Rutas



import org.springframework.data.jpa.repository.JpaRepository

interface RutasRepository: JpaRepository<Rutas, Long>






