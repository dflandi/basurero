package com.example.basurero.repository
import Student


import org.springframework.data.jpa.repository.JpaRepository

interface StudentRepository: JpaRepository<Student, Long>{
    fun findById(id:Long?):Student?
}






