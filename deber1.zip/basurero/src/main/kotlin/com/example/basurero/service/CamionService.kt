
import com.example.basurero.repository.CamionRepository
import org.springframework.beans.factory.annotation.Autowired

import org.springframework.stereotype.Service

@Service
class CamionService {
    @Autowired
    lateinit var camionRepository: CamionRepository
    fun list() : List<Camion> {
        return camionRepository.findAll()
        }
    fun save (camion:Camion):Camion{
        return camionRepository.save(camion)
    }
}