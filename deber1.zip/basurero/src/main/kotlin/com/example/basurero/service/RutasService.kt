
import com.example.basurero.repository.RutasRepository
import org.springframework.beans.factory.annotation.Autowired

import org.springframework.stereotype.Service

@Service
class RutasService {
    @Autowired
    lateinit var rutasRepository: RutasRepository
    fun list() : List<Rutas> {
        return rutasRepository.findAll()
        }
    fun save (rutas:Rutas):Rutas{
        return rutasRepository.save(rutas)
    }
}