
import com.example.basurero.repository.StudentRepository
import org.springframework.beans.factory.annotation.Autowired

import org.springframework.stereotype.Service

@Service
class StudentService {
    @Autowired
    lateinit var studentRepository: StudentRepository
    fun list() : List<Student> {
        return studentRepository.findAll()
        }
    fun save (student:Student):Student{
        return studentRepository.save(student)
    }

    //update tb set  name = "juan" where  id=3
    fun update (student:Student):Student{
    studentRepository.findById(student.id) ?: throw Exception()
        return studentRepository.save(student)

    }
    fun updateName(student: Student):Student{
        //Variable inmutable: VAL y la otra es var xd
        val response = studentRepository.findById(student.id)
            ?: throw Exception()

       response.apply{
           name=student.name
       }
        return studentRepository.save(response)

    }
}