

import com.example.basurero.repository.UsuariosRepository
import org.springframework.beans.factory.annotation.Autowired

import org.springframework.stereotype.Service

@Service
class UsuariosService {
    @Autowired
    lateinit var usuariosRepository: UsuariosRepository
        fun list() : List<Usuarios> {
        return usuariosRepository.findAll()
        }

    fun save (usuarios: Usuarios):Usuarios{
        return usuariosRepository.save(usuarios)
    }
}