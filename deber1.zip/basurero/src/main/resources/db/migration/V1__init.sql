CREATE TABLE IF NOT EXISTS Usuarios(
  id SERIAL,
      Nombre VARCHAR (100) NOT NULL,
      Edad INT,
      PRIMARY KEY (id)
      );

      CREATE TABLE IF NOT EXISTS Camion(
        id SERIAL,
         Hora INT,
         Dias INT,

            PRIMARY KEY (id)

            );

            CREATE TABLE IF NOT EXISTS Rutas(
              id SERIAL,
                  NombreRutas VARCHAR (100) NOT NULL,
                  TiempoRuta INT,
                  PRIMARY KEY (id)
                  );